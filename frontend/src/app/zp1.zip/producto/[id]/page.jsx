'use client';
import './producto-individual.css';
import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { FaCalendarCheck, FaMapMarkedAlt, FaWhatsapp, FaArrowLeft, FaChevronLeft, FaChevronRight } from "react-icons/fa";
import Navbar from '../../components/Navbar/Navbar';
import Footer from '../../components/Footer/Footer';
import ScrollToTop from '../../components/ScrollToTop/ScrollToTop';

// Datos por defecto si no se encuentra el producto
const productoDefault = {
  id: 1,
  nombre: "Camisa Reforsada T-800",
  precio: 2499.00,
  descripcion: "Envíos a toda la república mexicana.",
  marca: "Cummins",
  numeroParte: "56859",
  imagenes: [
    "/imgs/productos/camisa-t800-1.jpg",
    "/imgs/productos/camisa-t800-2.jpg", 
    "/imgs/productos/camisa-t800-3.jpg"
  ],
  detalles: {
    parQueServe: "El regulador en motores Cummins PX8 controla el flujo de combustible para óptimo rendimiento y eficiencia.",
    funcion: "Mantiene el flujo adecuado de combustible al motor.",
    importancia: [
      "Mejor rendimiento.",
      "Mayor eficiencia.", 
      "Protección del motor."
    ],
    conclusion: "Un buen regulador asegura tu Cummins PX8. Explora nuestras refacciones Cummins."
  }
};

// Productos relacionados simulados
const productosRelacionados = [
  {
    id: 2,
    nombre: "Camisa de Motor XR-5",
    precio: 1299.00,
    descripcion: "Camisa de alta resistencia, compatible, de tornillo esgado con modelo xx",
    imagen: "/imgs/productos/camisa-xr5.jpg"
  },
  {
    id: 3,
    nombre: "Camisa de Motor XR-5",
    precio: 1299.00,
    descripcion: "Camisa de alta resistencia, compatible, de tornillo esgado con modelo xx",
    imagen: "/imgs/productos/camisa-xr5-2.jpg"
  },
  {
    id: 4,
    nombre: "Camisa de Motor XR-5",
    precio: 1299.00,
    descripcion: "Camisa de alta resistencia, compatible, de tornillo esgado con modelo xx",
    imagen: "/imgs/productos/camisa-xr5-3.jpg"
  }
];

export default function ProductoIndividualPage() {
  const router = useRouter();
  const [producto, setProducto] = useState(productoDefault);
  const [imagenActual, setImagenActual] = useState(0);
  const [currentRelatedIndex, setCurrentRelatedIndex] = useState(0);

  // Cargar datos del producto desde localStorage
  useEffect(() => {
    if (typeof window !== 'undefined') {
      const productoGuardado = localStorage.getItem('producto-seleccionado');
      if (productoGuardado) {
        try {
          const productoData = JSON.parse(productoGuardado);
          
          // Expandir datos del producto con información adicional
          const productoCompleto = {
            ...productoData,
            // Si no tiene imágenes múltiples, usar la imagen principal
            imagenes: productoData.imagenes || [
              productoData.imagen,
              productoData.imagen,
              productoData.imagen
            ],
            // Agregar detalles por defecto si no los tiene
            detalles: productoData.detalles || {
              parQueServe: `Esta refacción ${productoData.nombre} está diseñada para brindar el máximo rendimiento y durabilidad en motores diésel ${productoData.marca}.`,
              funcion: `Garantiza el funcionamiento óptimo del sistema al que pertenece, manteniendo los estándares de calidad de ${productoData.marca}.`,
              importancia: [
                "Mejor rendimiento del motor.",
                "Mayor eficiencia operativa.", 
                "Protección y durabilidad extendida.",
                "Compatibilidad garantizada."
              ],
              conclusion: `Una excelente opción para mantener tu motor ${productoData.marca} en perfectas condiciones. Explora más refacciones en nuestro catálogo.`
            }
          };
          
          setProducto(productoCompleto);
        } catch (error) {
          console.error('Error al cargar datos del producto:', error);
          setProducto(productoDefault);
        }
      }
    }
  }, []);

  const handleVolver = () => {
    router.back();
  };

  const handleWhatsAppClick = (productoParam = producto) => {
    const message = encodeURIComponent(
      `Hola, estoy interesado en ${productoParam.nombre} con precio de $${productoParam.precio.toLocaleString()}. ${productoParam.numeroParte ? `Número de parte: ${productoParam.numeroParte}.` : ''} ¿Podría proporcionarme más información?`
    );
    const phoneNumber = '524272245923';
    const whatsappUrl = `https://api.whatsapp.com/send?phone=${phoneNumber}&text=${message}`;
    window.open(whatsappUrl, '_blank');
  };

  const nextRelatedProduct = () => {
    setCurrentRelatedIndex((prev) => 
      prev === productosRelacionados.length - 1 ? 0 : prev + 1
    );
  };

  const prevRelatedProduct = () => {
    setCurrentRelatedIndex((prev) => 
      prev === 0 ? productosRelacionados.length - 1 : prev - 1
    );
  };

  return (
    <div className="layout producto-individual-page">
      {/* Header con información de contacto y ubicación */}
      <header className="infoHeader">
        <div className="locationInfo">
          <span className="locationIcon"><FaMapMarkedAlt /></span>
          <span>Queretaro, San Juan del Río, San Cayetano, Río Extoras 56.</span>
        </div>
        <div className="line"></div>
        <div className="scheduleInfo">
          <span className="calendarIcon"><FaCalendarCheck /></span>
          <span>Lun - Vier. 9:00 am - 6:00 pm</span>
        </div>
      </header>

      {/* Navbar principal con botón de regreso */}
      <nav className="navbarWithBack">
        <div className="backButtonContainer">
          <button className="backButton" onClick={handleVolver}>
            <FaArrowLeft />
            Volver
          </button>
        </div>
        <Navbar />
      </nav>

      {/* Contenido principal */}
      <main className="mainContent">
        
        {/* Información del Producto */}
        <section className="productoMainSection">
          <div className="productoContainer">
            
            {/* Galería de Imágenes */}
            <div className="galeriaContainer">
              <div className="imagenPrincipal">
                <img 
                  src={producto.imagenes[imagenActual]}
                  alt={producto.nombre}
                  className="imagenProducto"
                />
              </div>
              
              {/* Miniaturas */}
              <div className="miniaturasContainer">
                {producto.imagenes.map((img, index) => (
                  <div
                    key={index}
                    onClick={() => setImagenActual(index)}
                    className={`miniatura ${imagenActual === index ? 'active' : ''}`}
                  >
                    <img 
                      src={img}
                      alt={`${producto.nombre} ${index + 1}`}
                      className="imagenMiniatura"
                    />
                  </div>
                ))}
              </div>
            </div>

            {/* Información del Producto */}
            <div className="productoInfoContainer">
              <h1 className="productoTitulo">{producto.nombre}</h1>

              <div className="productoPrecio">
                ${producto.precio.toLocaleString()}
              </div>

              <p className="productoDescripcion">
                {producto.descripcion}
              </p>

              <div className="productoDetalles">
                <div className="detalleItem">
                  <h4>Marca:</h4>
                  <p>{producto.marca}</p>
                </div>

                {producto.numeroParte && (
                  <div className="detalleItem">
                    <h4>Número de Parte:</h4>
                    <p>{producto.numeroParte}</p>
                  </div>
                )}
              </div>

              <button
                className="whatsappBtnPrincipal"
                onClick={() => handleWhatsAppClick()}
              >
                <FaWhatsapp />
                Compra por WhatsApp
              </button>
            </div>
          </div>
        </section>

        {/* Descripción Detallada */}
        <section className="descripcionSection">
          <div className="descripcionContainer">
            <h2 className="descripcionTitulo">Descripción</h2>

            <div className="descripcionContent">
              <div className="descripcionItem">
                <h3>¿Para que sirve?</h3>
                <p>{producto.detalles.parQueServe}</p>
              </div>

              <div className="descripcionItem">
                <h3>Función:</h3>
                <p>{producto.detalles.funcion}</p>
              </div>

              <div className="descripcionItem">
                <h3>Importancia:</h3>
                <ul>
                  {producto.detalles.importancia.map((item, index) => (
                    <li key={index}>{item}</li>
                  ))}
                </ul>
              </div>

              <div className="descripcionItem">
                <h3>Conclusión</h3>
                <p>{producto.detalles.conclusion}</p>
              </div>
            </div>
          </div>
        </section>

        {/* Productos Relacionados */}
        <section className="relacionadosSection">
          <div className="relacionadosContainer">
            <h2 className="relacionadosTitulo">PRODUCTOS RELACIONADOS</h2>

            <div className="relacionadosContent">
              <div className="relacionadosGrid">
                {productosRelacionados.map((productoRel) => (
                  <div key={productoRel.id} className="relacionadoCard">
                    
                    <div className="relacionadoImageContainer">
                      <img 
                        src={productoRel.imagen}
                        alt={productoRel.nombre}
                        className="relacionadoImage"
                      />
                    </div>

                    <div className="relacionadoInfo">
                      <h3 className="relacionadoNombre">{productoRel.nombre}</h3>
                      <p className="relacionadoDescripcion">{productoRel.descripcion}</p>
                      <div className="relacionadoPrecio">
                        ${productoRel.precio.toLocaleString()}
                      </div>
                      <button
                        className="relacionadoWhatsappBtn"
                        onClick={() => handleWhatsAppClick(productoRel)}
                      >
                        <FaWhatsapp />
                        Compra por WhatsApp
                      </button>
                    </div>
                  </div>
                ))}
              </div>

              {/* Navegación del carrusel */}
              <div className="carruselNavegacion">
                <button
                  className="carruselBtn prev"
                  onClick={prevRelatedProduct}
                >
                  <FaChevronLeft />
                </button>

                <button
                  className="carruselBtn next"
                  onClick={nextRelatedProduct}
                >
                  <FaChevronRight />
                </button>
              </div>
            </div>
          </div>
        </section>
      </main>

      {/* Footer */}
      <Footer />

      {/* Botón ScrollToTop */}
      <ScrollToTop />
    </div>
  );
}